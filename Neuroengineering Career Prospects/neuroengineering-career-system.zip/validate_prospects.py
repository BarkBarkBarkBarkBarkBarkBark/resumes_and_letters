#!/usr/bin/env python3
"""Validate a prospects export against its schema and the canonical skills JSON.

Usage: python validate_prospects.py prospects.json neuroengineering_skills.json
Uses the Python standard library; applies JSON Schema too when jsonschema is installed.
"""
import json
import sys
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit


def load(path):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValueError(f'duplicate JSON key: {key}')
            out[key] = value
        return out
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def validate(data, skills):
    tables = {'companies':'company_id','people':'person_id','jobs':'job_id',
              'job_skills':'job_skill_id','interviews':'interview_id',
              'outreach_events':'event_id','learning_projects':'project_id',
              'skill_proposals':'proposal_id','run_log':'run_id'}
    ids = {}
    for table, field in tables.items():
        values = [row[field] for row in data[table]]
        if any(not value for value in values) or len(values) != len(set(values)):
            raise ValueError(f'{table}: missing or duplicate ID')
        ids[table] = set(values)
    def ref(value, table):
        if value and value not in ids[table]:
            raise ValueError(f'unknown {table} ID: {value}')
    def skill(value):
        if value and value not in skills['skills']:
            raise ValueError(f'unknown skill ID: {value}')
    links = []
    for row in data['people']:
        ref(row['company_id'],'companies')
        if row['public_email'] and not row['email_source_url']:
            raise ValueError('public email requires its published source')
        links.append(row['linkedin_url'].lower().rstrip('/'))
    if len(links) != len(set(links)):
        raise ValueError('duplicate LinkedIn profile')
    posts=[]
    for row in data['jobs']:
        ref(row['company_id'],'companies')
        u=urlsplit(row['posting_url'])
        posts.append(urlunsplit((u.scheme,u.netloc,u.path.rstrip('/'),'','')))
    if len(posts) != len(set(posts)):
        raise ValueError('duplicate job posting URL')
    edge_keys=[]
    for row in data['job_skills']:
        ref(row['job_id'],'jobs');skill(row['skill_id'])
        edge_keys.append((row['job_id'],row['skill_id'],row['requirement_level']))
        if row['requirement_level']=='required_alternative' and not row['alternative_group']:
            raise ValueError('required alternative needs an alternative_group')
    if len(edge_keys)!=len(set(edge_keys)):
        raise ValueError('duplicate job-skill edge')
    for row in data['interviews']:
        ref(row['person_id'],'people');skill(row['skill_id'])
    for row in data['outreach_events']:
        ref(row['person_id'],'people')
    for row in data['learning_projects']:
        for s in row['skill_ids']:skill(s)
        for c in row['target_company_ids']:ref(c,'companies')
        ref(row['source_interview_id'],'interviews')
    for row in data['skill_proposals']:
        if row['skill'] or row['resume_include']:
            raise ValueError('new skill proposals must not claim experience')
    return {key:len(data[key]) for key in tables}


if __name__=='__main__':
    try:
        path=Path(sys.argv[1]);data=load(path);skills=load(sys.argv[2])
        schema_path=path.with_name('prospects.schema.json')
        if schema_path.exists():
            try:
                from jsonschema import Draft202012Validator
                Draft202012Validator(load(schema_path)).validate(data)
            except ImportError:
                pass
        print(json.dumps({'valid':True,'counts':validate(data,skills)},indent=2))
    except (ValueError,KeyError,OSError,IndexError) as exc:
        print(str(exc),file=sys.stderr);sys.exit(1)
